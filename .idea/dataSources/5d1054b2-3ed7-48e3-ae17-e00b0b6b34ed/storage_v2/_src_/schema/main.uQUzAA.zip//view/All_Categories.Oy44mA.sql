CREATE VIEW "All Categories" AS SELECT	CategoryID,Description
		FROM Categories
                          WHERE CategoryID LIKE '_';

